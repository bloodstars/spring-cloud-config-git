package com.wanda.configserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableDiscoveryClient
@EnableConfigServer
public class ConfigServerApplication {

    public static void main(String[] args) {
		System.setProperty("server.port", "8888");//default is 8080
		System.setProperty("spring.application.name", "default-config-server");
		
		System.setProperty("zookeeper.host", "10.199.204.25");
		System.setProperty("zookeeper.port", "2181");//default is 2181
		
//		System.setProperty("eureka.host", "localhost");
//		System.setProperty("eureka.port", "8761");//default is 2181
		
//		System.setProperty("consul.host", "localhost");
//		System.setProperty("consul.port", "8500");//default is 8500
		
		if(System.getProperty("spring.application.name") == null){
			System.setProperty("spring.application.name", "default-config-server");
		}
		
		if(System.getProperty("consul.host") != null){
			System.setProperty("consul.enabled", "true");
		}else if(System.getProperty("eureka.host") != null){
			System.setProperty("eureka.enabled", "true");
		}else if(System.getProperty("zookeeper.host") != null){
			System.setProperty("zookeeper.enabled", "true");
		}else{
			throw new RuntimeException("eureka or zookeeper or consul must be ready.");
		}
		
        SpringApplication.run(ConfigServerApplication.class, args);
    }

}
