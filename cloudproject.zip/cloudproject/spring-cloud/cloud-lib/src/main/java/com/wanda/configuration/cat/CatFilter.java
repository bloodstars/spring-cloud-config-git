package com.wanda.configuration.cat;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import org.springframework.web.filter.GenericFilterBean;

import com.dianping.cat.Cat;
import com.dianping.cat.message.Message;
import com.dianping.cat.message.Transaction;

public class CatFilter extends GenericFilterBean {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		Transaction t = CatConfiguration.currentTransaction.get();

		try {
			filterChain.doFilter(request, response);
			t.setStatus(Message.SUCCESS);
			Cat.logEvent(" STATUS ", " SUCCESS ");
		} catch (Throwable e) {
			t.setStatus(e);
			Cat.logError(e);
			throw e;
		}
	}
}
