package com.wanda.configuration.cat;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Event;
import com.google.gson.Gson;

@Aspect
public class CatControllerAspect {

	private static final Gson gson = new Gson();

	@Pointcut("@within(org.springframework.web.bind.annotation.RestController) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	private void anyRestControllerAnnotated() { }

	@Around("anyRestControllerAnnotated()")
	public Object _Controller_RequestMapping_Around(ProceedingJoinPoint pjp) throws Throwable {

		try {
			Cat.logEvent(CatConstants.TYPE_REQUEST, " [HTTP-REQUEST] " , Event.SUCCESS, gson.toJson(pjp.getArgs()));
		} catch (Exception e) { /* nothing */ }

		Object res = pjp.proceed();

		try {
			Cat.logEvent(CatConstants.TYPE_RESPONSE, " [HTTP-RESPONS] " , Event.SUCCESS, gson.toJson(res));
		} catch (Exception e) {
			/* nothing */}

		return res;
	}
}
