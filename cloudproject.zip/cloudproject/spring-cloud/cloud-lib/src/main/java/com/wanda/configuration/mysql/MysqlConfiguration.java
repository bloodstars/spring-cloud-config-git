package com.wanda.configuration.mysql;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Stream;

import org.apache.tomcat.jdbc.pool.ConnectionPool;
import org.apache.tomcat.jdbc.pool.JdbcInterceptor;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.apache.tomcat.jdbc.pool.PooledConnection;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;
import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Event;
import com.google.gson.Gson;
import org.apache.tomcat.jdbc.pool.DataSource;

@Configuration
@Conditional(MysqlConfiguration.class)
public class MysqlConfiguration implements EnvironmentAware, BeanDefinitionRegistryPostProcessor, Condition{

	private static Gson gson = new Gson();
	
	private Map<String, PoolProperties> datasources = new HashMap<>();
	
	@Override
	public void setEnvironment(Environment environment) {
		RelaxedPropertyResolver propertyResolver = new RelaxedPropertyResolver(environment, "datasource.");
		for(String key : propertyResolver.getSubProperties("").keySet()){
			String realKey = key.substring(0, key.indexOf("."));
			if(!datasources.containsKey(realKey))
				datasources.put(realKey, gson.fromJson(gson.toJson(propertyResolver.getSubProperties(realKey + ".")), PoolProperties.class));
		}
		if(Boolean.valueOf(new RelaxedPropertyResolver(environment).getProperty("cat.switch"))){
			for(PoolProperties p : datasources.values()){
				p.setJdbcInterceptors(p.getJdbcInterceptors() == null ? MysqlCatInterceptor.class.getName() : p.getJdbcInterceptors() + ";" + MysqlCatInterceptor.class.getName());
			}
		}
	}

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
		for(Entry<String, PoolProperties> datasource : datasources.entrySet()){
			BeanDefinition definition = beanFactory.getBeanDefinition(datasource.getKey());
			definition.getPropertyValues().addPropertyValue("poolProperties", datasource.getValue());
		}
	}
	
	@Override
	public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
		BeanDefinitionBuilder beanDefinition = BeanDefinitionBuilder.genericBeanDefinition(DataSource.class);
		for(Entry<String, PoolProperties> datasource : datasources.entrySet()){
			registry.registerBeanDefinition(datasource.getKey(), beanDefinition.getBeanDefinition());
		}
	}

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		RelaxedPropertyResolver propertyResolver = new RelaxedPropertyResolver(context.getEnvironment());
		return !propertyResolver.getSubProperties("datasource.").isEmpty();
	}
	
	public static class MysqlCatInterceptor extends JdbcInterceptor{
		@Override
		public void reset(ConnectionPool parent, PooledConnection con) {}
		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			StringBuilder builder = new StringBuilder("Request : ");
			if(args != null){
				Stream.of(args).forEach(item -> builder.append(String.valueOf(item)).append(" ; "));
			}
			Cat.logEvent(CatConstants.TYPE_SQL, method.getName(), Event.SUCCESS, builder.toString());
			Object res = super.invoke(proxy, method, args);
			Cat.logEvent(CatConstants.TYPE_SQL, method.getName(), Event.SUCCESS, "Result : " + String.valueOf(res));
			return res;
		}
	}
}
