package com.wanda.configuration.cat;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.sleuth.instrument.web.TraceFilter;
import org.springframework.cloud.sleuth.log.SpanLogger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.dianping.cat.Cat;
import com.dianping.cat.message.Transaction;

@Configuration
@ConditionalOnProperty(value = "cat.switch")
public class CatConfiguration {
	
	@Value("${cat.ip}")
	private String ips;
	@Value("${cat.domain}")
	private String domain;

	@PostConstruct
	public void postInit() {
		Cat.setClientInfo(ips, domain);
		Cat.getProducer();
	}
	
	public static final ThreadLocal<Transaction> currentTransaction = new ThreadLocal<Transaction>();
	
	@Bean
	public CatControllerAspect catAspect(){
		return new CatControllerAspect();
	}
	
	@Bean
	public CatFilter catFilter(TraceFilter trace) {
		return new CatFilter();
	}
	
	@Bean
	public SpanLogger catLogger() {
		return new CatLogger();
	}
}
