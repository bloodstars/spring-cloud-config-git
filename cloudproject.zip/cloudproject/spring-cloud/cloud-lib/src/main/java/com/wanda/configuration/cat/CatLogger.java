package com.wanda.configuration.cat;

import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.log.SpanLogger;

import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Event;
import com.dianping.cat.message.Transaction;
import com.dianping.cat.message.spi.MessageTree;
import com.google.gson.Gson;

public class CatLogger implements SpanLogger {

	private static final Gson gson = new Gson();
	@Override 
	public void logStartedSpan(Span parent, Span span) {
		if(!isLog(parent, span))
			return;
		
		Transaction t = Cat.newTransaction(CatConstants.TYPE_URL, span.getName());
		CatConfiguration.currentTransaction.set(t);
		
		MessageTree tree = Cat.getManager().getThreadLocalMessageTree();
		tree.setMessageId(genCatMessageId(span.getSpanId()));
		if(parent != null){
			tree.setParentMessageId(genCatMessageId(parent.getSpanId()));
		}
		tree.setRootMessageId(genCatMessageId(span.getTraceId()));
		
	}
	@Override
	public void logStoppedSpan(Span parent, Span span) {
		if(!isLog(parent, span))
			return;
		
		if(parent != null){
			Cat.logEvent(CatConstants.TYPE_CALL, " [ PARENT-SPAN ] " , Event.SUCCESS, gson.toJson(parent));
		}
		Cat.logEvent(CatConstants.TYPE_CALL, " [ SON-SPAN ] " , Event.SUCCESS, gson.toJson(span));
		
		Transaction t = CatConfiguration.currentTransaction.get();
		
		if(t != null)
			t.complete();
		
		CatConfiguration.currentTransaction.remove();
	}

	private static final boolean isLog(Span parent, Span span){
		if(span == null || parent == span)
			return false;
		
		if(span.getName() == null )
			return false;
		
		return span.getName().startsWith("http");
	}
	
	@Override public void logContinuedSpan(Span span) {}

	
	private static String genCatMessageId(long spanId){
		return String.format("%s-%s-%d-%d", Cat.domain, String.valueOf(Math.abs(spanId)), System.currentTimeMillis() / 3600000, Math.abs(spanId % 10000));
	}
}
