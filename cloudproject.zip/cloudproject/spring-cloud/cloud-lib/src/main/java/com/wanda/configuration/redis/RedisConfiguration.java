package com.wanda.configuration.redis;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Event;

import redis.clients.jedis.JedisPoolConfig;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@Configuration
@ConditionalOnProperty(value = "redis.switch")
public class RedisConfiguration {

	@Value("${redis.master.ip}")
	private String masterIp;
	@Value("${redis.master.port}")
	private int port;
	@Value("${redis.sentinel:}")
	private String sentinel;
	@Value("${redis.mastername:}")
	private String masterName;
	@Value("${redis.minPoolSize:10}")
	private int minPoolSize;
	@Value("${redis.maxPoolSize:30}")
	private int maxPoolSize;
	@Value("${redis.maxWaitTime:1000}")
	private int maxWaitTime;

	@Value("${cat.switch:false}")
	private boolean catOn;

	@Bean
	@ConditionalOnMissingBean
	public RedisConnectionFactory jedisConnectionFactory() {
		JedisPoolConfig pollConfig = new JedisPoolConfig();
		pollConfig.setMaxIdle(maxPoolSize);
		pollConfig.setMaxTotal(maxPoolSize);
		pollConfig.setMinIdle(minPoolSize);
		pollConfig.setMaxWaitMillis(maxWaitTime);

		JedisConnectionFactory factory = null;
		
		if (StringUtils.isEmpty(sentinel)) {
			factory = new JedisConnectionFactory(pollConfig);
		} else {
			RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration();
			for (String sentinel : sentinel.split(",")) {
				String[] slave_add_port = sentinel.split(":");
				sentinelConfig.addSentinel(new RedisNode(slave_add_port[0], Integer.parseInt(slave_add_port[1])));
			}
			sentinelConfig.setMaster(masterName);
			factory = new JedisConnectionFactory(sentinelConfig, pollConfig);
		}

		factory.setHostName(masterIp);
		factory.setPort(port);

		factory.afterPropertiesSet();

		return factory;
	}

	@Bean(name = "redisTemplate")
	@ConditionalOnBean(RedisConnectionFactory.class)
	@ConditionalOnMissingBean
	public StringRedisTemplate redisTemplate(final RedisConnectionFactory factory) {
		StringRedisTemplate template = null;
		if(catOn){
			template = new StringRedisTemplate() {
				@Override
				protected RedisConnection createRedisConnectionProxy(final RedisConnection pm) {
					Class<?>[] ifcs = ClassUtils.getAllInterfacesForClass(pm.getClass(), getClass().getClassLoader());
					return (RedisConnection) Proxy.newProxyInstance(pm.getClass().getClassLoader(), ifcs,
							new InvocationHandler() {
								@Override
								public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
									StringBuilder builder = new StringBuilder();
									if (args != null) {
										builder.append("param : \n");
										Stream.of(args).forEach(item -> {
											if (item instanceof byte[] || item instanceof Byte[]) {
												builder.append(new String((byte[]) item)).append("\n");
											} else {
												builder.append(item.toString()).append("\n");
											}
										});
									}
									Cat.logEvent("Redis", method.getName(), Event.SUCCESS, builder.toString());
									Object res = method.invoke(pm, args);
									Cat.logEvent(CatConstants.TYPE_SQL, method.getName(), Event.SUCCESS, "Result : " + String.valueOf(res));
									return res;
								}
							});
				}
				@Override
				public <T> T execute(RedisCallback<T> action, boolean exposeConnection, boolean pipeline) {
					return super.execute(action, false, pipeline);
				}
			};
		}else{
			template = new StringRedisTemplate();
		}
		template.setExposeConnection(false);
		template.setConnectionFactory(factory);
		template.afterPropertiesSet();
		
		return template;
	}
}
