package com.wanda.configuration.dubbo;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ConsumerConfig;
import com.alibaba.dubbo.config.MonitorConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.spring.ReferenceBean;
import com.dianping.cat.Cat;
import com.dianping.cat.message.Event;
import com.google.common.collect.Lists;
import com.google.gson.Gson;

/**
 * 扫描包，把包内的interface作为dubbo的client加进来
 * @author li
 */

@Configuration
@Conditional(DubboClientConfiguration.class)
public class DubboClientConfiguration implements Condition{

	private static final String basePackage = "com.wanda";
	
	private static final Gson gson = new Gson();
	
	@Value("${dubbo.check:false}")
	private boolean check;
	@Value("${spring.application.name}")
	private String appName;
	@Value("${zookeeper.host}")
	private String zkIp;
	@Value("${zookeeper.port:2181}")
	private int port;
	
	@Bean
	public ConsumerConfig dubboConsumerConfig() {
		ConsumerConfig config = new ConsumerConfig();
		config.setId(ConsumerConfig.class.getName());
		config.setCheck(false);
		return config;
	}
	
	@Bean
	public MonitorConfig dubboMonitorConfig() {
		MonitorConfig config = new MonitorConfig();
		config.setId(MonitorConfig.class.getName());
		config.setProtocol("registry");
		return config;
	}
	
	@Bean
	public ApplicationConfig dubboApplicationConfig() {
		return new ApplicationConfig(appName);
	}
	
	@Bean
	public List<RegistryConfig> dubboRegistryConfig() {
		RegistryConfig registryConfig = new RegistryConfig(zkIp + ":" + port);
		registryConfig.setPort(port);
		registryConfig.setCheck(false);
		registryConfig.setProtocol("zookeeper");
		registryConfig.setId(RegistryConfig.class.getName());
		return Lists.newArrayList(registryConfig);
	}

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		return !scannerEnable.findCandidateComponents(basePackage).isEmpty();
	}
	
	static ClassPathScanningCandidateComponentProvider scannerCertainPackage = new ClassPathScanningCandidateComponentProvider(false) {
		@Override
		protected boolean isCandidateComponent(MetadataReader metadataReader){
			try {
				return Class.forName(metadataReader.getClassMetadata().getClassName()).isInterface();
			} catch (ClassNotFoundException e) { return false; }
		}
		
		@Override
		protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
			return true;
		}
	};
	
	static ClassPathScanningCandidateComponentProvider scannerEnable = new ClassPathScanningCandidateComponentProvider(true) {
		@Override
		protected void registerDefaultFilters() {
			this.addIncludeFilter(new AnnotationTypeFilter(DubboClientScan.class));
		}
	};
	
	private static void registryBean(BeanDefinition define ,BeanDefinitionRegistry registry){
		AnnotatedBeanDefinition annotatedDefine = (AnnotatedBeanDefinition) define;
		BeanDefinitionBuilder definition = BeanDefinitionBuilder.genericBeanDefinition(CatReferenceBean.class);
		try { definition.addPropertyValue("interfaceClass", Class.forName(annotatedDefine.getBeanClassName())); } catch (ClassNotFoundException e) { }
		definition.addPropertyReference("registries", "dubboRegistryConfig");
		definition.addPropertyReference("monitor", "dubboMonitorConfig");
		definition.addPropertyReference("consumer", "dubboConsumerConfig");
		definition.addPropertyReference("application", "dubboApplicationConfig");
		registry.registerBeanDefinition(annotatedDefine.getBeanClassName(), definition.getBeanDefinition());
	}
	
	@Configuration
	@Conditional(DubboClientConfiguration.class)
	public static class DubboPostProcesser implements BeanFactoryPostProcessor{
		@Override
		public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
			
			for(BeanDefinition define : scannerEnable.findCandidateComponents(basePackage)){
				try {
					DubboClientScan scan = Class.forName(define.getBeanClassName()).getAnnotation(DubboClientScan.class);
					if(scan.packageToScan().length > 0){
						Stream.of(scan.packageToScan()).forEach(item -> {
							Set<BeanDefinition> bbb = scannerCertainPackage.findCandidateComponents(item);
							for(BeanDefinition d : bbb){
								registryBean(d, (BeanDefinitionRegistry)beanFactory);
							}
						});
					}
				} catch (Exception e) {}
			}
		}
	}
	
	public static class CatReferenceBean<T> extends ReferenceBean<T>{
		private static final long serialVersionUID = -2273173010243248654L;

		@Value("${cat.switch:false}")
		private boolean catOn;
	    
		@SuppressWarnings("unchecked")
		@Override
		public T getObject() throws Exception{
			final Object obj = super.getObject();
			
			if(catOn){
				return (T)Proxy.newProxyInstance(DubboClientConfiguration.class.getClassLoader(), new Class[]{getInterfaceClass()}, new InvocationHandler(){
					@Override
					public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
						StringBuilder builder = new StringBuilder("Request : ");
						if(args != null){
							Stream.of(args).forEach(item -> builder.append(gson.toJson(item)).append(" ; "));
						}
						Cat.logEvent("DUBBO-CLIENT", method.getName(), Event.SUCCESS, builder.toString());
						
						Object result = method.invoke(obj, args);
						
						Cat.logEvent("DUBBOO-CLIENT", method.getName(), Event.SUCCESS, gson.toJson(result));
						return result;
					}
				});
			}else{
				return (T)obj;
			}
			
		}
	}
}
