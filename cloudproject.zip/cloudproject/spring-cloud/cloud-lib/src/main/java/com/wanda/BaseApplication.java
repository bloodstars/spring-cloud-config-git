package com.wanda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.type.ClassMetadata;
import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
import org.springframework.core.type.classreading.MetadataReaderFactory;

@SpringBootApplication(exclude={DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
@EnableDiscoveryClient
@EnableFeignClients
@EnableHystrix
public class BaseApplication {
	
	public static void main(String[] args) throws Exception {
		SpringApplication application = new SpringApplication(BaseApplication.class);
		ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
		MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory(resourcePatternResolver);
		
		//所有extends了BaseApplication的类，都被作为resource加入到启动中。
		for(Resource resource : resourcePatternResolver.getResources("classpath*:com/wanda/**/*.class")){
			ClassMetadata classMeta = metadataReaderFactory.getMetadataReader(resource).getClassMetadata();
			if(BaseApplication.class.getName().equals(classMeta.getSuperClassName())){
				application.getSources().add(Class.forName(classMeta.getSuperClassName()));
			}
		}
		
		if(System.getProperty("consul.host") != null){
			System.setProperty("consul.enabled", "true");
		}else if(System.getProperty("eureka.host") != null){
			System.setProperty("eureka.enabled", "true");
		}else if(System.getProperty("zookeeper.host") != null){
			System.setProperty("zookeeper.enabled", "true");
		}else{
			throw new RuntimeException("eureka or zookeeper or consul must be ready.");
		}

		application.run(args);
	}
}
