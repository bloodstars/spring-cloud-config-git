package com.wanda.configuration.dubbo;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import com.alibaba.dubbo.config.spring.ServiceBean;
import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Event;
import com.dianping.cat.message.Message;
import com.dianping.cat.message.Transaction;
import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ConsumerConfig;
import com.alibaba.dubbo.config.MonitorConfig;
import com.alibaba.dubbo.config.ProviderConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.google.common.collect.Lists;
import com.google.gson.Gson;

@Configuration
@Conditional(DubboServerConfiguration.class)
public class DubboServerConfiguration implements Condition {

	private static final String basePackage = "com.wanda";

	private static final Gson gson = new Gson();

	@Value("${dubbo.check:false}")
	private boolean check;
	@Value("${spring.application.name}")
	private String appName;
	@Value("${zookeeper.host}")
	private String zkIp;
	@Value("${zookeeper.port:2181}")
	private int port;
	@Value("${dubbo.filter:}")
	private String dubboFilter;

	@Bean
	public ConsumerConfig dubboConsumerConfig() {
		ConsumerConfig config = new ConsumerConfig();
		config.setId(ConsumerConfig.class.getName());
		config.setCheck(false);
		return config;
	}

	@Bean
	public MonitorConfig dubboMonitorConfig() {
		MonitorConfig config = new MonitorConfig();
		config.setId(MonitorConfig.class.getName());
		config.setProtocol("registry");
		return config;
	}

	@Bean
	public ApplicationConfig dubboApplicationConfig() {
		return new ApplicationConfig(appName);
	}

	@Bean
	public List<RegistryConfig> dubboRegistryConfig() {
		RegistryConfig registryConfig = new RegistryConfig(zkIp + ":" + port);
		registryConfig.setPort(port);
		registryConfig.setCheck(false);
		registryConfig.setProtocol("zookeeper");
		registryConfig.setId(RegistryConfig.class.getName());
		return Lists.newArrayList(registryConfig);
	}

	@Bean
	public ProviderConfig dubboProviderConfig() {
		ProviderConfig config = new ProviderConfig();
		config.setId(ProviderConfig.class.getName());
		if (StringUtils.isNotBlank(dubboFilter))
			config.setFilter(dubboFilter);
		return config;
	}

	@Configuration
	@Conditional(DubboServerConfiguration.class)
	public static class DubboPostProcesser implements BeanFactoryPostProcessor {
		@Override
		public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
			for (BeanDefinition define : scannerEnable.findCandidateComponents(basePackage)) {
				try {
					DubboServerScan scan = Class.forName(define.getBeanClassName()).getAnnotation(DubboServerScan.class);
					if (scan.packageToScan().length > 0) {
						for (String pack : scan.packageToScan()) {
							Set<BeanDefinition> bbb = scannerCertainPackage.findCandidateComponents(pack);
							for (BeanDefinition d : bbb) {
								registryBean(Class.forName(d.getBeanClassName()), (BeanDefinitionRegistry) beanFactory);
							}
						}
					}
				} catch (Exception e) {}
			}
		}
	}

	private static void registryBean(Class<?> beanClass, BeanDefinitionRegistry registry) {
		Class<?> interfaceClass = beanClass.getInterfaces()[0];

		BeanDefinitionBuilder beanDefinition = BeanDefinitionBuilder.genericBeanDefinition(beanClass);
		registry.registerBeanDefinition(beanClass.getSimpleName(), beanDefinition.getBeanDefinition());

		BeanDefinitionBuilder beanCatFacBeanDefinition = BeanDefinitionBuilder.genericBeanDefinition(CatFactoryBean.class);
		beanCatFacBeanDefinition.addPropertyReference("ref", beanClass.getSimpleName());
		beanCatFacBeanDefinition.addPropertyValue("interfaceClass", interfaceClass.getName());
		registry.registerBeanDefinition(beanClass.getName(), beanCatFacBeanDefinition.getBeanDefinition());
		
		BeanDefinitionBuilder dubboDefinition = BeanDefinitionBuilder.genericBeanDefinition(ServiceBean.class);
		dubboDefinition.addPropertyValue("id", interfaceClass.getName());
		dubboDefinition.addPropertyReference("ref", beanClass.getName());
		dubboDefinition.addPropertyReference("registries", "dubboRegistryConfig");
		dubboDefinition.addPropertyValue("interface", interfaceClass.getName());
		dubboDefinition.addPropertyValue("timeout", 10000);
		dubboDefinition.addPropertyValue("retries", 0);
		registry.registerBeanDefinition(interfaceClass.getName(), dubboDefinition.getBeanDefinition());
	}

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		return !scannerEnable.findCandidateComponents(basePackage).isEmpty();
	}

	static ClassPathScanningCandidateComponentProvider scannerEnable = new ClassPathScanningCandidateComponentProvider(true) {
		@Override
		protected void registerDefaultFilters() {
			this.addIncludeFilter(new AnnotationTypeFilter(DubboServerScan.class));
		}
	};

	static ClassPathScanningCandidateComponentProvider scannerCertainPackage = new ClassPathScanningCandidateComponentProvider(false) {
		@Override
		protected boolean isCandidateComponent(MetadataReader metadataReader) {
			try {
				return Class.forName(metadataReader.getClassMetadata().getClassName()).getInterfaces().length == 1;
			} catch (ClassNotFoundException e) {
				return false;
			}
		}

		@Override
		protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
			return true;
		}
	};

	public static class CatFactoryBean implements FactoryBean<Object>{

		@Value("${cat.switch:false}")
		private boolean catOn;
		
		private Object ref;
		
		private Class<?> interfaceClass;
		
		public String getInterfaceClass() {
			return interfaceClass.getName();
		}

		public void setInterfaceClass(String interfaceName) throws ClassNotFoundException {
			interfaceClass = Class.forName(interfaceName);
		}

		public Object getRef() {
			return ref;
		}

		public void setRef(Object ref) {
			this.ref = ref;
		}

		@Override
		public Object getObject() throws Exception {
			final Object ref = this.ref;
			
			if(!catOn){
				return ref;
			}
			
			return Proxy.newProxyInstance(DubboServerConfiguration.class.getClassLoader(), ref.getClass().getInterfaces(), new InvocationHandler(){
				@Override
				public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
					Transaction t = Cat.newTransaction("DUBBO_SERVER", ref.getClass().getInterfaces()[0].getName());
					try {
						Cat.logEvent(CatConstants.TYPE_CALL, " [METHOD-NAME] ", Event.SUCCESS, method.getName());
						Cat.logEvent(CatConstants.TYPE_REQUEST, " [DUBBO-REQUEST] ", Event.SUCCESS, gson.toJson(args));
						
						Object res = method.invoke(ref, args);
						
						Cat.logEvent(CatConstants.TYPE_RESPONSE, " [DUBBO-RESPONS] ", Event.SUCCESS, gson.toJson(res));
						t.setStatus(Message.SUCCESS);
						Cat.logEvent(" STATUS ", " SUCCESS ");
						return res;
					} catch (Exception e) {
						t.setStatus(e);
						Cat.logError(e);
						throw e;
					} finally {
						t.complete();
					}
				}
			});
		}

		@Override
		public Class<?> getObjectType() {
			return interfaceClass;
		}

		@Override
		public boolean isSingleton() {
			return true;
		}
	}
}
