package com.wanda.gateway.filter;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "pre.request")
public class PreRequestProperties {

	public Map<String, Mapping> mappings = new HashMap<>();
	
	public Map<String, Mapping> getMappings() {
		return mappings;
	}

	public void setMappings(Map<String, Mapping> mappings) {
		this.mappings = mappings;
	}

	public static class Mapping{
		public String pattern;
		public String targetName;
		public String targetPath;
		public String targetResponse;
		
		public String getPattern() {
			return pattern;
		}

		public void setPattern(String pattern) {
			this.pattern = pattern;
		}

		public String getTargetName() {
			return targetName;
		}

		public void setTargetName(String targetName) {
			this.targetName = targetName;
		}

		public String getTargetPath() {
			return targetPath;
		}

		public void setTargetPath(String targetPath) {
			this.targetPath = targetPath;
		}

		public String getTargetResponse() {
			return targetResponse;
		}

		public void setTargetResponse(String targetResponse) {
			this.targetResponse = targetResponse;
		}

		private Pattern _pattern;
		private Pattern _targetResponse;
		
		public Pattern getPathPattern(){
			if(_pattern == null){
				_pattern = Pattern.compile(pattern);
			}
			return _pattern;
		}
		
		public Pattern getResponsePattern(){
			if(_targetResponse == null){
				_targetResponse = Pattern.compile(targetResponse);
			}
			return _targetResponse;
		}
	}
	
	public Mapping findMapping(String path){
		for(Mapping mapping : mappings.values()){
			if(mapping.getPathPattern().matcher(path).matches()){
				return mapping;
			}
		}
		return null;
	}
}
