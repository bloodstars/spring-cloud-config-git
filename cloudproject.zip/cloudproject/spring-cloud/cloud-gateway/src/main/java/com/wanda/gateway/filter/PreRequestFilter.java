package com.wanda.gateway.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.netflix.zuul.filters.ProxyRequestHelper;
import org.springframework.cloud.netflix.zuul.filters.route.RibbonCommand;
import org.springframework.cloud.netflix.zuul.filters.route.RibbonCommandContext;
import org.springframework.cloud.netflix.zuul.filters.route.RibbonCommandFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.MultiValueMap;

import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.http.ZuulServlet;
import com.wanda.gateway.filter.PreRequestProperties.Mapping;

@Configuration
@ConditionalOnClass(ZuulServlet.class)
@ConditionalOnProperty("pre.request.switch")
@EnableConfigurationProperties({PreRequestProperties.class})
public class PreRequestFilter extends ZuulFilter implements InitializingBean{
	
	@Autowired  
	PreRequestProperties properties;
	
	@Autowired
	RibbonCommandFactory<?> ribbonCommandFactory;
	
	protected ProxyRequestHelper helper = new ProxyRequestHelper();
	
	@Override
	public boolean shouldFilter() {
		HttpServletRequest request = RequestContext.getCurrentContext().getRequest();
		return properties.findMapping(request.getRequestURI()) != null;
	}

	@Override
	public Object run() {
		RequestContext context = RequestContext.getCurrentContext();
		
		Mapping mapping = properties.findMapping(context.getRequest().getRequestURI());
		
		RibbonCommand command = this.ribbonCommandFactory.create(buildCommandContext(context, mapping));
		
		try {
			ClientHttpResponse response = command.execute();
			BufferedReader r = new BufferedReader(new InputStreamReader(response.getBody()));
			StringBuilder builder = new StringBuilder();
			r.lines().forEach(item -> builder.append(item));
			if(!mapping.getResponsePattern().matcher(builder).matches()){
				context.setResponseBody(builder.toString());
				throw new RuntimeException();
			}
		}catch (IOException ex) {
			throw new RuntimeException(ex);
		}
		return true;
	}

	private RibbonCommandContext buildCommandContext(RequestContext context, Mapping mapping) {
		HttpServletRequest request = context.getRequest();

		MultiValueMap<String, String> headers = this.helper.buildZuulRequestHeaders(request);
		MultiValueMap<String, String> params = this.helper.buildZuulRequestQueryParams(request);
		
		String verb = request.getMethod() == null ? "GET" : request.getMethod();

		String serviceId = mapping.targetName;
		String uri = mapping.targetPath.replace("//", "/");

		return new RibbonCommandContext(serviceId, verb, uri, false, headers, params, null);
	}
	
	@Override
	public String filterType() {
		return "pre";
	}

	@Override
	public int filterOrder() {
		return Integer.MAX_VALUE;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		properties.mappings.values().forEach(item -> {
			item.getPathPattern();
			item.getResponsePattern();
		});
	}
}
