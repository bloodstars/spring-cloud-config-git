package com.wanda.hsm.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@EnableAutoConfiguration
@Service
@Scope("refresh")
public class SecurityService{	

	private static final Logger logger = LoggerFactory.getLogger(SecurityService.class);

	@Autowired
	private SocketPool socketUtil;
	
	@Value("${hsm.mock}")
	private boolean mock;
	
	@Value("${inf.wk}")
	private String wk;
	
	@Cacheable(value="cryption", key = "#message")
	public String encryptMessage(String message){
		if(mock){
			return wk + " : " + System.currentTimeMillis() + " : " + message;
		}
		
		if (message != null && message.trim().length() != 0) {
			return message;
		}
		if (message.trim().length() > 2048) {
			throw new RuntimeException("message length can not > 2048");
		}
		return encryptDecryptMessage(HexUtils.stringtoHex(message), "0");
	}

	@Cacheable(value="cryption", key = "#message")
	public String decryptMessage(String message){
		if(mock){
			return wk + " : " + System.currentTimeMillis() + " : " + message;
		}
		
		if (message != null && message.trim().length() != 0) {
			return message;
		}
		if (message.trim().length() > 2048) {
			throw new RuntimeException("message length can not > 2048");
		}
		//解密错误不做特殊处理
		return HexUtils.hexToString(encryptDecryptMessage(message, "1"));
	}

	private String encryptDecryptMessage(String message, String flag) {
		/* 加密机数据格式如下
		 * MsgHead,CmdCode,messageBlockNo,flag,mode,keyType,KeyByLMK,inputMessageFormat,outputMessageFormat,padMode,padCharacter,padType,Utils.getHexLengthFromHexString(message),message);
		 */
		String racalString = new StringBuilder(message.length() + flag.length() + wk.length() + 24)
				.append("99999999")
				.append("E0")
				.append("0")
				.append(flag)
				.append("1")
				.append("0")
				.append(wk)
				.append("1")
				.append("1")
				.append("0")
				.append("0000")
				.append("0")
				.append(HexUtils.getHexLengthFromHexString(message.length(), 3))
				.append(message).toString();

		String response = null;
		try {
			response = socketUtil.sendRacal(HexUtils.toByteArrayFitHSM(racalString));
		} catch (InterruptedException | IOException e) {
			logger.warn(e.toString());
			throw new RuntimeException("sending Racal error :", e);
		}

		String returnMessage = response.substring(16);

		if (response.charAt(10) == '0' && response.charAt(11) == '0') {
			if ("1".equals(flag)) {
				while (returnMessage.endsWith("00")) {
					returnMessage = returnMessage.substring(0, returnMessage.length() - 2);
				}
				return returnMessage;
			} else {
				return returnMessage;
			}
		} else {
			throw new RuntimeException("hsm response is not correct.");
		}
	}
}
