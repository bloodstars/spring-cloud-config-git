package com.wanda.hsm.controller;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wanda.hsm.service.SecurityService;

@RestController
public class HsmController implements ApplicationContextAware{
	
	//config from svn
    @Value("${message.svn}")
    private String svnMessage;
	
    @RequestMapping(value = "/encryptMessage", method = RequestMethod.POST)
    public String encryptMessage(@RequestBody String message) {
    	return ctx.getBean(SecurityService.class).encryptMessage(message);
    }
    
    @RequestMapping(value = "/decryptMessage", method = RequestMethod.POST)
    public String decryptMessage(@RequestBody String message) {
    	return ctx.getBean(SecurityService.class).decryptMessage(message);
    }

    private ApplicationContext ctx ;
    
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		ctx = applicationContext;
	}
}
