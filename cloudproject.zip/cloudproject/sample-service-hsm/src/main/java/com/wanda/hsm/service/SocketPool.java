package com.wanda.hsm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.io.Closeable;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@EnableAutoConfiguration
@Service
@Scope("refresh")
public class SocketPool{	
	private static final Logger logger = LoggerFactory.getLogger(SocketPool.class);
    
    @Value("${hsm.host}")
    private String hsmHost;
    @Value("${hsm.size}")
    private int poolSize;
    @Value("${hsm.mock}")
	private boolean mock ;
    
    private ArrayBlockingQueue<ArrayBlockingQueue<SocketPackage>> pool;
    
    private MonitorThread deamon;
    
    private SynchronousQueue<Object[]> exchanger = new SynchronousQueue<Object[]>();

    @PostConstruct
    public void init(){     	
    	if(mock)
    		return;
    	
    	String hosts[] = hsmHost.split(",");
    	
    	pool = new ArrayBlockingQueue<ArrayBlockingQueue<SocketPackage>>(hosts.length);
    	
		deamon = new MonitorThread();
		deamon.setName("SocketPool-deamon");
		deamon.setDaemon(true);
		deamon.start();
    	
		for(String host : hosts){
			String ip_port[] = host.split(":");
			try {
				pool.offer(createSocketPool(poolSize, ip_port[0], Integer.parseInt(ip_port[1])));
			} catch (Exception e) {
				throw new RuntimeException("Error to create a SocketChannel.", e);
			}
		}
    }
    
    @PreDestroy
    public void destoryPool() { 
    	System.out.println("destoryPool........................");
    	
    	if(deamon != null)
    		deamon.alive = false;
    	
    	if (pool != null) {
    		synchronized(this){
    			for(ArrayBlockingQueue<SocketPackage> smallPool : pool){
    				for(SocketPackage pkg : smallPool){
    					pkg.close();
    				}
    				smallPool.clear();
    			}
    			pool.clear();
    		}
        }
    }
    
    public String sendRacal(final byte[] racalRequest) throws InterruptedException, IOException{
    	
    	ArrayBlockingQueue<ArrayBlockingQueue<SocketPackage>> bigPool = pool;//volatile read
    	
    	ArrayBlockingQueue<SocketPackage> smallPool = bigPool.take();
    	
    	bigPool.put(smallPool);
    	
    	SocketPackage pkg = smallPool.take();
    	
		try {
			return pkg.writeAndRead(racalRequest);
		} catch(IOException e){
			pkg.close();
			try{
				pkg = new SocketPackage(pkg.ip, pkg.port);//优化，尝试重建一次。
			}catch(IOException e2){
				exchanger.offer(new Object[]{bigPool, smallPool, pkg.ip, pkg.port});
				throw e2;
			}
			return pkg.writeAndRead(racalRequest);
		}finally{
			smallPool.put(pkg);
		}
    }
    
    class SocketPackage implements Runnable, Closeable{
    	
    	String ip;
    	
    	int port;
    	
    	SocketChannel socketChannel;
    	
    	ByteBuffer readBuf = ByteBuffer.allocate(2048);
    	
    	ByteBuffer writeBuf = ByteBuffer.allocate(2048);
    	
		private SocketPackage(String ip, int port) throws IOException{
    		this.ip = ip;
    		this.port = port;
    		socketChannel = SocketChannel.open();
    		try{
    			socketChannel.setOption(StandardSocketOptions.SO_KEEPALIVE, true); 
            	socketChannel.setOption(StandardSocketOptions.SO_SNDBUF, 2048);  
            	socketChannel.setOption(StandardSocketOptions.SO_RCVBUF, 2048);
            	socketChannel.setOption(StandardSocketOptions.SO_LINGER, 0);
            	socketChannel.configureBlocking(true);
            	socketChannel.connect(new InetSocketAddress(ip, port));
    		}catch(Exception e){
    			close();
    			throw e;
    		}
        	deamon.addSocketToDeamon(socketChannel);
    	}
    	
    	public String writeAndRead(byte[] racalRequest) throws IOException{
    		writeBuf.clear();
    		writeBuf.put(racalRequest).flip();
    		while(writeBuf.hasRemaining()) {
    			socketChannel.write(writeBuf);
			}
    		readBuf.clear();
    		socketChannel.read(readBuf);
    		return new String(readBuf.array(), 2, readBuf.position() - 2);
    	}
    	
    	public boolean isOpen(){
    		return socketChannel.isOpen() && socketChannel.isConnected();
    	}
    	
    	@Override
    	public void close(){
    		try{
    			socketChannel.close();
			}catch(Exception e){/*nothing*/}
    	}
    	
    	@Override
		public void run() {
    		close();
		}
    }
	
	private ArrayBlockingQueue<SocketPackage> createSocketPool(int capacity, String ip, int port) throws IOException{
		ArrayBlockingQueue<SocketPackage> queue = new ArrayBlockingQueue<SocketPackage>(capacity);
		
		try {
			for(int index = 0; index < capacity ; index ++){
				queue.offer(new SocketPackage(ip, port));
			}
		} catch (IOException e) {
			for(SocketPackage pkg : queue){
				pkg.close();
			}
			throw e;
		}
		
		return queue;
	}
	
    private class MonitorThread extends Thread{
    	
    	public Queue<WeakReference<SocketChannel>> deamonQueue = new ConcurrentLinkedQueue<WeakReference<SocketChannel>>();
    	
    	public AtomicInteger count = new AtomicInteger();
    	
    	public Set<ArrayBlockingQueue<SocketPackage>> retrySet = new HashSet<ArrayBlockingQueue<SocketPackage>>();
    	
    	public volatile boolean alive = true;
    	
    	@SuppressWarnings("unchecked")
		@Override
		public void run() {
    		for(long deamonCount = 0 ; alive ; deamonCount ++){
    			
    			
    			Object[] bigPool_smallPool_ip_port = null;
    			
    			try {     bigPool_smallPool_ip_port = exchanger.poll(6000, TimeUnit.MILLISECONDS);    } catch (InterruptedException e) { /*nothing*/}
    			
    			if(bigPool_smallPool_ip_port != null){
    				logger.warn(String.format("SocketPool error , [%s]:[%d] is broken." , bigPool_smallPool_ip_port[2], bigPool_smallPool_ip_port[3]));
    				
    				ArrayBlockingQueue<ArrayBlockingQueue<SocketPackage>> big = (ArrayBlockingQueue<ArrayBlockingQueue<SocketPackage>>)bigPool_smallPool_ip_port[0];
    				
    				ArrayBlockingQueue<SocketPackage> small = (ArrayBlockingQueue<SocketPackage>)bigPool_smallPool_ip_port[1];
    				
    				synchronized(this){
    					while(!big.remove(small))
    						;
    					//try to repair.
    					while(small.remainingCapacity() != 0){
							try { Thread.sleep(10); } catch (InterruptedException e1) {/*nothing*/}
    					}
    					
        				for(SocketPackage pkg : small)
        					pkg.close();
    					
    					retrySet.add(small);
    				}
				}else if(!retrySet.isEmpty()){
					synchronized(this){
						Iterator<ArrayBlockingQueue<SocketPackage>> it = retrySet.iterator();
						while(it.hasNext()){
							ArrayBlockingQueue<SocketPackage> small = it.next();
							
							String ip = small.peek().ip;
							int port = small.peek().port;
							
							logger.warn(String.format("SocketPool error , [%s]:[%d] is broken, and now is repairing." , ip, port));
							
							try {
								pool.offer(createSocketPool(poolSize, ip, port));//重试成功，加入到大池子当中。
								small.clear();
								it.remove();
							} catch (Exception e) {
								logger.warn(String.format("SocketPool error , [%s]:[%d] still not connected. " , ip, port));
							}
						}
					}
				}
    			
    			if(deamonCount % 10 == 0){
    				printAndPing();
    			}
    		}
    	}
    	
		public void addSocketToDeamon(SocketChannel socket){
    		if(socket != null){
    			deamonQueue.add(new WeakReference<SocketChannel>(socket));
    			count.incrementAndGet();
    		}
    	}
		
		private void printAndPing(){
			int alive = 0, dead = 0;
			Iterator<WeakReference<SocketChannel>> it = deamonQueue.iterator();
			while(it.hasNext()){
				SocketChannel socket = it.next().get();
				if(socket == null){
					it.remove();
				}else{
					if(!socket.isConnected()){
						dead ++ ;
					}else if(socket.isConnected()){
						alive ++ ;
					}
				}
			}
			logger.info(String.format("SocketPool status : alive[%d], dead[%d]. Count of all socket newed : [%d]", alive, dead, count.get()));
		}
    }

    
}
