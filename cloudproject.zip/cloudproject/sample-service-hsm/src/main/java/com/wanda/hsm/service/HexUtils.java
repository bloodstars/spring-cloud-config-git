package com.wanda.hsm.service;

/**
 * User: caoli
 * Date: 16/3/23
 * Time: 下午2:02
 */
public final class HexUtils {
	
    private static final char[] HEX_CHAR = new char[]{'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

    private static final int digit = 16;

    public static final String stringtoHex(String str) {
        byte[] strBytes = str.getBytes();
        
        char[] buffer = new char[strBytes.length * 2];
        
        for(int i = 0; i < strBytes.length; i ++) {
        	buffer[i * 2]     = HEX_CHAR[(strBytes[i] & 240) >> 4];
        	buffer[i * 2 + 1] = HEX_CHAR[(strBytes[i] &  15) >> 0];	
        }
        
        return new String(buffer);
    }
    
    public static final String hexToString(String hex) {
        byte[] result = new byte[hex.length() / 2];
        for(int i = 0; i < hex.length(); i += 2) {
        	result[ i/2 ] = (byte)Math.abs(Character.digit(hex.charAt(i), digit) * digit + Character.digit(hex.charAt(i + 1), digit));
        }
        return new String(result);
    }
    
    public static final String getHexLengthFromHexString(int length, int count) {
    	if(count > 8)
    		throw new RuntimeException("String length no more than 8");
    	
    	char[] hexLength = new char[count];
    	
    	for(int index = 0; index < count; index ++){
    		hexLength[index] = HEX_CHAR[length << (31 - 4 * (count - index)) >>> 28];
    	}
    	
        return new String(hexLength);
    }
    
    public static final byte[] toByteArrayFitHSM(String racalCommand) {
        byte[] strBytes = racalCommand.getBytes();
        byte[] result = new byte[strBytes.length + 2];
        result[0] = (byte)(strBytes.length >>> 8 & 255);
        result[1] = (byte)(strBytes.length >>> 0 & 255);
        System.arraycopy(strBytes, 0, result, 2, strBytes.length);
        return result;
    }
}

