package com.wanda._main;

import com.wanda.BaseApplication;
import com.wanda.configuration.dubbo.DubboClientScan;

@DubboClientScan(packageToScan = { "com.wanda.dubbo.client"})
public class Web extends BaseApplication {

	public static void main(String args[]) throws Exception {
		
		System.setProperty("server.port", "8081");// default is 8080
		System.setProperty("spring.application.name", "sample-web");
		
		System.setProperty("zookeeper.host", "10.199.204.25");
		System.setProperty("zookeeper.port", "2181");// default is 2181

//		System.setProperty("eureka.host", "localhost");
//		System.setProperty("eureka.port", "8761");//default is 2181

//		System.setProperty("consul.host", "localhost");
//		System.setProperty("consul.port", "8500");//default is 8500
		
		BaseApplication.main(args);
	}
}
