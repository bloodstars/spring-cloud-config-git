package com.wanda.consumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wanda.consumer.feign.HelloClient;
import com.wanda.consumer.feign.HsmClient;
import com.wanda.dubbo.client.IAccountService;
import com.wanda.dubbo.client.IQueryPersonalService;

@RestController
public class WebController{
	
    @Value("${message.svn}")//this config is from svn...
    private String svnMessage;
	
	@Autowired
	private HelloClient pongClient; //this is restful client

	@Autowired
	private HsmClient hsm; //this is restful client
	
	@Autowired
	IQueryPersonalService ser ;//this is a dubbo client
	
	@Autowired
	IAccountService ser2;//this is a dubbo client
	
	@RequestMapping("/dispatch")
	public MessageAcknowledgement sendMessage(@RequestBody String message) {
		System.out.println("sendMessage.............");
		if (message.indexOf("dubbo") >= 0) {
			String ss = ser.getPersonalMember(100000010012744680L);
			String ddd = ser2.makeNormal(100000010012744680L);
			String ooo = ser2.makeCancel(1L);
			return new MessageAcknowledgement(ss,ooo,ddd);
		}
	    else if (message.indexOf("hsm") >= 0) {
			String enc = hsm.encryptMessage(message);
			String dec = hsm.decryptMessage(message);
			return new MessageAcknowledgement(enc + dec, enc + dec, enc + dec);
		} else {
			String res = pongClient.sendMessage(message);
			return new MessageAcknowledgement(res, res, res);
		} 
	}

	@RequestMapping("/check")
	public String check() {
		System.out.println("check.............");
		return "OK";
	}
	
	public static class MessageAcknowledgement {

		private String id;
		private String received;
		private String payload;

		public MessageAcknowledgement(String id, String received, String payload) {
			this.id = id;
			this.received = received;
			this.payload = payload;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getReceived() {
			return received;
		}

		public void setReceived(String received) {
			this.received = received;
		}

		public String getPayload() {
			return payload;
		}

		public void setPayload(String payload) {
			this.payload = payload;
		}
	}
}
