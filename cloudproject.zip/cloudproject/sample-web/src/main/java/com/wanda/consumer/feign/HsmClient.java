package com.wanda.consumer.feign;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient("sample-service-hsm")
public interface HsmClient {

	@RequestMapping(method = RequestMethod.GET, value = "/encryptMessage", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	String encryptMessage(String message);

	@RequestMapping(method = RequestMethod.GET, value = "/decryptMessage", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	String decryptMessage(String message);
}