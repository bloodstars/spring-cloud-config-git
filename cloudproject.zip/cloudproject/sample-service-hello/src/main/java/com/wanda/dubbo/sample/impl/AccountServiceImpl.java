package com.wanda.dubbo.sample.impl;

import com.wanda.dubbo.client.IAccountService;

/**
 * User: yifei.qin
 * Date: 16/3/6
 * Time: 上午10:28
 */
public class AccountServiceImpl implements IAccountService {
	@Override
	public String makeNormal(Long PWID) {
		System.out.println("AccountServiceImpl........");
		return "makeNormal";
	}

	@Override
	public String makeCancel(final Long PWID) {
		System.out.println("AccountServiceImpl........");
		return "makeCancel";
	}

	@Override
	public String makeToActive(final Long PWID) {
		System.out.println("AccountServiceImpl........");
		return "makeCancel";
	}

	@Override
	public String makeFreeze(final Long PWID) {
		System.out.println("AccountServiceImpl........");
		return "makeFreeze";

	}

}