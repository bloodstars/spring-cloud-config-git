package com.wanda.dubbo.sample.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcContext;
import com.alibaba.dubbo.rpc.RpcException;
import com.alibaba.dubbo.rpc.RpcResult;
import com.alibaba.dubbo.rpc.service.GenericService;

/**
 * User: change.long
 * Date: 16/3/16
 * Time: 下午5:16
 */
@Activate(group = Constants.PROVIDER, order = -1000)
public class UAPExceptionFilter implements Filter {

	public Logger logger;

	public UAPExceptionFilter() {
		this(LoggerFactory.getLogger(UAPExceptionFilter.class));
	}

	public UAPExceptionFilter(Logger logger) {
		this.logger = logger;
	}

	@Override
	public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
		try {
			Result e = invoker.invoke(invocation);
			if (e.hasException() && GenericService.class != invoker.getInterface()) {
				try {
					Throwable exceptionInternal = e.getException();
					logger.error("Got unchecked and undeclared exception which called by "
							+ RpcContext.getContext().getRemoteHost() + ". service: " + invoker.getInterface().getName()
							+ ", method: " + invocation.getMethodName() + ", exception: "
							+ exceptionInternal.getClass().getName() + ": " + exceptionInternal.getMessage(),
							exceptionInternal);

					exceptionInternal.printStackTrace();
					return (new RpcResult(new RuntimeException(exceptionInternal)));
				} catch (Throwable throwsCatch) {
					logger.error("Got unchecked and undeclared exception which called by "
							+ RpcContext.getContext().getRemoteHost() + ". service: " + invoker.getInterface().getName()
							+ ", method: " + invocation.getMethodName() + ", exception: " + e.getClass().getName()
							+ ": " + throwsCatch.getMessage(), e);

					throwsCatch.printStackTrace();
					return e;
				}
			} else {
				return e;
			}
		} catch (RuntimeException exception) {
			logger.error("Got unchecked and undeclared exception which called by "
					+ RpcContext.getContext().getRemoteHost() + ". service: " + invoker.getInterface().getName()
					+ ", method: " + invocation.getMethodName() + ", exception: " + exception.getClass().getName()
					+ ": " + exception.getMessage(), exception);
			exception.printStackTrace();
			throw exception;
		}
	}
}
