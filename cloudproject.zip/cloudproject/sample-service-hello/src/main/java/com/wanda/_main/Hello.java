package com.wanda._main;

import com.wanda.BaseApplication;
import com.wanda.configuration.dubbo.DubboServerScan;

@DubboServerScan(packageToScan = {"com.wanda.dubbo.sample.impl"})
public class Hello extends BaseApplication {
	
	public static void main(String args[]) throws Exception{
		System.setProperty("server.port", "8082");//default is 8080
		System.setProperty("spring.application.name", "sample-service-hello");
		System.setProperty("zookeeper.host", "10.199.204.25");
		System.setProperty("zookeeper.port", "2181");//default is 2181
//		System.setProperty("eureka.host", "localhost");
//		System.setProperty("eureka.port", "8761");//default is 2181
		BaseApplication.main(args);
	}
}