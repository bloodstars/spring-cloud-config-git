package com.wanda.dubbo.client;

/**
 * User: yifei.qin
 * Date: 16/3/6
 * Time: 上午10:47
 */
public interface IAccountService {

	/**
	 * 会员修改至正常
	 * @param 	ModifyMemberStatusReq 修改状态服务
	 * @return	请求成功直接给ModifyMemberStatusResp
	 */
	public String makeNormal(Long PWID);

	/**
	 * 会员修改至注销
	 * @param 	ModifyMemberStatusReq 修改状态服务
	 * @return	请求成功直接给ModifyMemberStatusResp
	 */
	public String makeCancel(Long PWID);

	/**
	 * 会员修改至待激活
	 * @param 	ModifyMemberStatusReq 修改状态服务
	 * @return	请求成功直接给ModifyMemberStatusResp
	 */
	public String makeToActive(Long PWID);

	/**
	 * 会员修改至冻结
	 * @param 	ModifyMemberStatusReq 修改状态服务
	 * @return	请求成功直接给ModifyMemberStatusResp
	 */
	public String makeFreeze(Long PWID);

}
