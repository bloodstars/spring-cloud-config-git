/**

 * Project Name:uap-query-service
 * File Name:IQueryPersonalService.java
 * Package Name:com.wanda.uap.service.query
 * 会员信息查询类
 * Date:2016年3月28日下午1:46:28
 * Copyright (c) 2016, wanda.cn All Rights Reserved.
 *
*/

package com.wanda.dubbo.client;

/**
 * ClassName:IQueryPersonalService <br/>
 * Date:     2016年3月28日 下午1:46:28 <br/>
 * @author   zhiwu.mo
 * @version  
 * @see 	 
 */
public interface IQueryPersonalService {
	public String getPersonalMember(final Long PWID);
}
