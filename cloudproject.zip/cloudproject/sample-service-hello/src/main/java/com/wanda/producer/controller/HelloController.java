package com.wanda.producer.controller;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	public HelloController(){
		System.out.println("11111");
	}
	
    @Value("${reply.message}")
    private String message;
    
    //config from svn
    @Value("${message.svn}")
    private String svnMessage;
    
    @Resource
    DataSource data1;
    
    @Resource
    DataSource data2;
    
    @Autowired
    StringRedisTemplate r;
    
    @RequestMapping(value = "/message", method = RequestMethod.POST)
    public String pongMessage(@RequestBody String input) throws SQLException {
    	Connection con = data1.getConnection();
    	CallableStatement stat = con.prepareCall("select 1 from dual");
    	stat.executeQuery();
    	con.close();
    	
    	con = data2.getConnection();
    	stat = con.prepareCall("select 1 from dual");
    	stat.executeQuery();
    	con.close();
    	
    	r.opsForValue().get("AAA");
    	r.opsForValue().set("AAA", "CCC");
    	r.opsForValue().get("AAA");
    	
        return message;
    }
}
