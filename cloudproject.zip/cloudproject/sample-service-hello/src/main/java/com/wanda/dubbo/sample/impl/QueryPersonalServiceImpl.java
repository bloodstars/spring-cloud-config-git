package com.wanda.dubbo.sample.impl;

import com.wanda.dubbo.client.IQueryPersonalService;

/**
 * User: yongbin.jiang 
 * Date: 16/3/9
 * Time: 20:33
 */
public class QueryPersonalServiceImpl implements IQueryPersonalService {
	@Override
	public String getPersonalMember(Long PWID) {
		System.out.println("QueryPersonalServiceImpl........");
		return "getPersonalMember";
	}
}